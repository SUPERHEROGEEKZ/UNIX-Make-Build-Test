/*
 * Filename     main.cc
 * Date         09/29/2020 
 * Author       Zainab Anwar with help from Professor Stephen Perkins' popenExample.cc
 * Email        zxa180005@utdallas.edu
 * Course       CS 3377.002 Fall 2020
 * Version      1.0
 * Copyright 2020, All Rights Reserved
 *
 * Description
 *
 * A file that opens and closes two pipes and receives output from gawk,
 * gawk.code, and numbers.txt.
 * Prints out the version of gawk and some other information.
 * Prints out the parsed sum of columns 1 and 4 from numbers.txt individually,                         
 * then sums up the two numbers.
 *
 */

#include "header.h"

using namespace std;

// Max size of a line to read from the pipe
#define BUFFER_SIZE 1024


int main(int argc, char *argv[])
{
  FILE *output_from_command;
  char tmpbuffer[BUFFER_SIZE];
  char *line_p;
  

  // This is a C++ style string object that contains
  // the shell command.
  string shellcmd1 = "/home/012/z/zx/zxa180005/bin/gawk --version";
  string shellcmd2 = "/home/012/z/zx/zxa180005/bin/gawk -f gawk.code numbers.txt";  
  string gawkdirectory = "/home/012/z/zx/zxa180005/bin/gawk";

  // Print it to the screen for good measure
  // Good for debugging
  cout << endl;
  cout << "\tgawk at: " << gawkdirectory << endl;
  cout << "\tShellcmd1: " << shellcmd1 << endl;
  cout << "\tShellcmd2: " << shellcmd2 << endl;
  
  // Now... Execute the shell command.  The output
  // from the command is returned as file stream.
  // Remember... popen wants a C style string... not a 
  // c++ String Object.
  output_from_command = popen(shellcmd1.c_str(), "r");

  // make sure it opened else error out
  if (!output_from_command)
    return -1;

  // Now... treat the output from the command as if it
  // were an open file.  Just read from the file and 
  // display to screen.
  
  cout << endl;
  cout << "\tThe first call to gawk returned:" << endl << endl;

  // Read at most BUFFER_SIZE bytes from file and store in 
  // tmpbuffer.  Returns NULL on EOF.
  line_p = fgets(tmpbuffer, BUFFER_SIZE, output_from_command);
 
  // While it is not the last line, continue printing and reading
  while(line_p != NULL)
    {
      printf("\t%s", line_p);
      line_p = fgets(tmpbuffer, BUFFER_SIZE, output_from_command);
    }
 
  // make sure we close what we open.
  pclose(output_from_command);

  cout << endl;

  // Now... Execute the shell command.  The output                                                              
  // Remember... popen wants a C style string... not a                                                         
  // c++ String Object.                                                                                         
  output_from_command = popen(shellcmd2.c_str(), "r");

  // make sure it opened else error out                                                                         
  if (!output_from_command)
    return -1;

  // Now... treat the output from the command as if it                                                          
  // display to screen.                                                                                         
  cout << "\tThe second call to gawk returned: ";

  // Read at most BUFFER_SIZE bytes from file and store in                                                     
  // tmpbuffer.  Returns NULL on EOF.                                                                           
  line_p = fgets(tmpbuffer, BUFFER_SIZE, output_from_command);
  cout << line_p << endl; 
  int* sums = parse(line_p);  
  int sum1 = sums[0];
  int sum4 = sums[1];
  delete [] sums;

  // make sure we close what we open.                                                                           
  pclose(output_from_command);
 
  cout << "\tThe sum of Column 1 is: " << sum1 << endl;
  cout << "\tThe sum of Column 4 is: " << sum4 << endl;
  cout << "\tThe Sum of the two numbers is: " << sum1 + sum4 << endl;
 
  cout << endl;
  
  return 0;
}
