/*
 * Filename     parse.cc
 * Date         09/29/2020 
 * Author       Zainab Anwar
 * Email        zxa180005@utdallas.edu
 * Course       CS 3377.002 Fall 2020
 * Version      1.0
 * Copyright 2020, All Rights Reserved
 *
 * Description
 *
 * A file that parses the c-style strings into ints in order to be used properly.
 *
 */

#include "header.h"

using namespace std;

int* parse(char* line_p)
{
  int* array = new int [2];
  string convert= string(line_p);

  istringstream ss(convert);
    ss >> array[0] >> array[1];
  return array;
}
