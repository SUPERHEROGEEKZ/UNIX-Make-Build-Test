/*                                                                                                     
 * Filename     header.h                                                                               
 * Date         09/29/2020                                                                             
 * Author       Zainab Anwar
 * Email        zxa180005@utdallas.edu                                                                 
 * Course       CS 3377.002 Fall 2020                                                                  
 * Version      1.0                                                                                    
 * Copyright 2020, All Rights Reserved                                                                 
 *                                                                                                     
 * Description                                                                                         
 *                                                                                                     
 * A header file that contains all of the #include statements
 * used in this program as well as the function header.
 *                                                                                                     
 */

#ifndef _HEADER_
#define _HEADER_

#include <iostream>
#include <string>
#include <stdio.h>
#include <stdlib.h>
#include <sstream>
#include <fstream>

int* parse(char* line_p);

#endif
